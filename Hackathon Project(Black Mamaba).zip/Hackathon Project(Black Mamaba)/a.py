import sklearn
print(sklearn.__version__)