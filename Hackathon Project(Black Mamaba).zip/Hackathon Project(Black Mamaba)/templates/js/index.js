// script.js

// Function to highlight a state when clicked
function highlightState(stateName) {
    var stateElement = document.querySelector("li"); // Get the first <li> element
    stateElement.style.backgroundColor = "yellow"; // Change the background color
  }
  
  // Add an event listener to each list item to call the highlightState function
  var stateItems = document.querySelectorAll("li");
  stateItems.forEach(function (item) {
    item.addEventListener("click", function () {
      highlightState(item.textContent); // Pass the state name to the function
    });
  });
  